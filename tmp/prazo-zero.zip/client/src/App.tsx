import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Tasks from "./pages/Tasks";
import Deadlines from "./pages/Deadlines";
import Documents from "./pages/Documents";
import Notifications from "./pages/Notifications";
import Integrations from "./pages/Integrations";
import GmailIntegration from "./pages/GmailIntegration";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/tasks"} component={Tasks} />
      <Route path={"/deadlines"} component={Deadlines} />
      <Route path={"/documents"} component={Documents} />
      <Route path={"/notifications"} component={Notifications} />
      <Route path={"/integrations"} component={Integrations} />
      <Route path={"/integrations/gmail"} component={GmailIntegration} />
      <Route path={"/integrations/gmail/callback"} component={GmailIntegration} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
