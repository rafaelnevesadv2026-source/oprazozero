import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2, Calendar } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function Deadlines() {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    dueDate: "",
    priority: "medium",
    category: "",
  });

  const { data: deadlines = [], refetch } = trpc.deadlines.list.useQuery();
  const createMutation = trpc.deadlines.create.useMutation();
  const updateMutation = trpc.deadlines.update.useMutation();
  const deleteMutation = trpc.deadlines.delete.useMutation();

  const handleCreate = async () => {
    if (!formData.title.trim() || !formData.dueDate) {
      toast.error("Título e data são obrigatórios");
      return;
    }

    try {
      await createMutation.mutateAsync({
        title: formData.title,
        description: formData.description || undefined,
        dueDate: new Date(formData.dueDate),
        priority: formData.priority as any,
        category: formData.category || undefined,
      });
      toast.success("Prazo criado com sucesso!");
      setFormData({ title: "", description: "", dueDate: "", priority: "medium", category: "" });
      setOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao criar prazo");
    }
  };

  const handleToggleStatus = async (deadlineId: number, currentStatus: string) => {
    const newStatus = currentStatus === "completed" ? "pending" : "completed";
    try {
      await updateMutation.mutateAsync({
        id: deadlineId,
        status: newStatus as any,
        completedAt: newStatus === "completed" ? new Date() : undefined,
      });
      refetch();
    } catch (error) {
      toast.error("Erro ao atualizar prazo");
    }
  };

  const handleDelete = async (deadlineId: number) => {
    try {
      await deleteMutation.mutateAsync({ id: deadlineId });
      toast.success("Prazo deletado");
      refetch();
    } catch (error) {
      toast.error("Erro ao deletar prazo");
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-100 text-red-800";
      case "high":
        return "bg-orange-100 text-orange-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-green-100 text-green-800";
    }
  };

  const groupedDeadlines = {
    pending: deadlines.filter(d => d.status === "pending"),
    completed: deadlines.filter(d => d.status === "completed"),
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Prazos</h1>
            <p className="text-foreground/60 mt-1">Acompanhe seus prazos importantes</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Novo Prazo
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Novo Prazo</DialogTitle>
                <DialogDescription>
                  Adicione um novo prazo importante
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Título</label>
                  <Input
                    placeholder="Título do prazo"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Descrição</label>
                  <Textarea
                    placeholder="Descrição detalhada"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Data de Vencimento</label>
                    <Input
                      type="date"
                      value={formData.dueDate}
                      onChange={(e) =>
                        setFormData({ ...formData, dueDate: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Prioridade</label>
                    <Select
                      value={formData.priority}
                      onValueChange={(value) =>
                        setFormData({ ...formData, priority: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Baixa</SelectItem>
                        <SelectItem value="medium">Média</SelectItem>
                        <SelectItem value="high">Alta</SelectItem>
                        <SelectItem value="critical">Crítica</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Categoria</label>
                  <Input
                    placeholder="Ex: legal, pagamento, projeto"
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({ ...formData, category: e.target.value })
                    }
                  />
                </div>
                <Button
                  onClick={handleCreate}
                  disabled={createMutation.isPending}
                  className="w-full"
                >
                  {createMutation.isPending ? "Criando..." : "Criar Prazo"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Pending Deadlines */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-500" />
              Prazos Pendentes ({groupedDeadlines.pending.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {groupedDeadlines.pending.length === 0 ? (
              <p className="text-foreground/60 text-center py-8">
                Nenhum prazo pendente
              </p>
            ) : (
              <div className="space-y-3">
                {groupedDeadlines.pending.map((deadline) => (
                  <div
                    key={deadline.id}
                    className="flex items-center justify-between p-4 bg-accent/50 rounded-lg border border-border hover:border-primary transition-colors group"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{deadline.title}</p>
                      {deadline.description && (
                        <p className="text-sm text-foreground/60">{deadline.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        {deadline.category && (
                          <Badge variant="outline">{deadline.category}</Badge>
                        )}
                        <p className="text-xs text-foreground/60">
                          {deadline.dueDate && format(new Date(deadline.dueDate), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getPriorityColor(deadline.priority)}>
                        {deadline.priority === "critical" ? "Crítico" :
                         deadline.priority === "high" ? "Alto" :
                         deadline.priority === "medium" ? "Médio" : "Baixo"}
                      </Badge>
                      <button
                        onClick={() => handleToggleStatus(deadline.id, deadline.status)}
                        className="px-3 py-1 text-sm bg-green-100 text-green-800 rounded hover:bg-green-200 transition-colors"
                      >
                        ✓
                      </button>
                      <button
                        onClick={() => handleDelete(deadline.id)}
                        className="p-1 hover:bg-destructive/10 rounded opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Completed Deadlines */}
        {groupedDeadlines.completed.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-green-500" />
                Prazos Concluídos ({groupedDeadlines.completed.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {groupedDeadlines.completed.map((deadline) => (
                  <div
                    key={deadline.id}
                    className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800 group"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-foreground line-through opacity-60">
                        {deadline.title}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDelete(deadline.id)}
                      className="p-1 hover:bg-destructive/10 rounded opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
