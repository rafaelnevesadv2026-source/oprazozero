import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2, CheckCircle2, Circle } from "lucide-react";
import { toast } from "sonner";

export default function Tasks() {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    priority: "medium",
    dueDate: "",
  });

  const { data: tasks = [], refetch } = trpc.tasks.list.useQuery();
  const createMutation = trpc.tasks.create.useMutation();
  const updateMutation = trpc.tasks.update.useMutation();
  const deleteMutation = trpc.tasks.delete.useMutation();

  const handleCreate = async () => {
    if (!formData.title.trim()) {
      toast.error("Título é obrigatório");
      return;
    }

    try {
      await createMutation.mutateAsync({
        title: formData.title,
        description: formData.description || undefined,
        priority: formData.priority as any,
        dueDate: formData.dueDate ? new Date(formData.dueDate) : undefined,
      });
      toast.success("Tarefa criada com sucesso!");
      setFormData({ title: "", description: "", priority: "medium", dueDate: "" });
      setOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao criar tarefa");
    }
  };

  const handleToggleStatus = async (taskId: number, currentStatus: string) => {
    const newStatus = currentStatus === "completed" ? "pending" : "completed";
    try {
      await updateMutation.mutateAsync({
        id: taskId,
        status: newStatus as any,
        completedAt: newStatus === "completed" ? new Date() : undefined,
      });
      refetch();
    } catch (error) {
      toast.error("Erro ao atualizar tarefa");
    }
  };

  const handleDelete = async (taskId: number) => {
    try {
      await deleteMutation.mutateAsync({ id: taskId });
      toast.success("Tarefa deletada");
      refetch();
    } catch (error) {
      toast.error("Erro ao deletar tarefa");
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-100 text-red-800";
      case "high":
        return "bg-orange-100 text-orange-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-green-100 text-green-800";
    }
  };

  const groupedTasks = {
    pending: tasks.filter(t => t.status === "pending"),
    inProgress: tasks.filter(t => t.status === "in_progress"),
    completed: tasks.filter(t => t.status === "completed"),
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Tarefas</h1>
            <p className="text-foreground/60 mt-1">Gerencie suas tarefas diárias</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Nova Tarefa
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Nova Tarefa</DialogTitle>
                <DialogDescription>
                  Adicione uma nova tarefa à sua lista
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Título</label>
                  <Input
                    placeholder="Título da tarefa"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Descrição</label>
                  <Textarea
                    placeholder="Descrição detalhada"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Prioridade</label>
                    <Select
                      value={formData.priority}
                      onValueChange={(value) =>
                        setFormData({ ...formData, priority: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Baixa</SelectItem>
                        <SelectItem value="medium">Média</SelectItem>
                        <SelectItem value="high">Alta</SelectItem>
                        <SelectItem value="critical">Crítica</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Data de Vencimento</label>
                    <Input
                      type="date"
                      value={formData.dueDate}
                      onChange={(e) =>
                        setFormData({ ...formData, dueDate: e.target.value })
                      }
                    />
                  </div>
                </div>
                <Button
                  onClick={handleCreate}
                  disabled={createMutation.isPending}
                  className="w-full"
                >
                  {createMutation.isPending ? "Criando..." : "Criar Tarefa"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Pending Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Circle className="w-5 h-5 text-yellow-500" />
              Pendentes ({groupedTasks.pending.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {groupedTasks.pending.length === 0 ? (
              <p className="text-foreground/60 text-center py-8">
                Nenhuma tarefa pendente
              </p>
            ) : (
              <div className="space-y-2">
                {groupedTasks.pending.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between p-4 bg-accent/50 rounded-lg border border-border hover:border-primary transition-colors group"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <button
                        onClick={() => handleToggleStatus(task.id, task.status)}
                        className="p-1 hover:bg-accent rounded transition-colors"
                      >
                        <Circle className="w-5 h-5 text-foreground/40" />
                      </button>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{task.title}</p>
                        {task.description && (
                          <p className="text-sm text-foreground/60">{task.description}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getPriorityColor(task.priority)}>
                        {task.priority === "critical" ? "Crítica" :
                         task.priority === "high" ? "Alta" :
                         task.priority === "medium" ? "Média" : "Baixa"}
                      </Badge>
                      <button
                        onClick={() => handleDelete(task.id)}
                        className="p-1 hover:bg-destructive/10 rounded opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* In Progress Tasks */}
        {groupedTasks.inProgress.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Circle className="w-5 h-5 text-blue-500" />
                Em Progresso ({groupedTasks.inProgress.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {groupedTasks.inProgress.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800 group"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <button
                        onClick={() => handleToggleStatus(task.id, task.status)}
                        className="p-1 hover:bg-blue-100 rounded transition-colors"
                      >
                        <Circle className="w-5 h-5 text-blue-500" />
                      </button>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{task.title}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getPriorityColor(task.priority)}>
                        {task.priority === "critical" ? "Crítica" :
                         task.priority === "high" ? "Alta" :
                         task.priority === "medium" ? "Média" : "Baixa"}
                      </Badge>
                      <button
                        onClick={() => handleDelete(task.id)}
                        className="p-1 hover:bg-destructive/10 rounded opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Completed Tasks */}
        {groupedTasks.completed.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
                Concluídas ({groupedTasks.completed.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {groupedTasks.completed.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800 group"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <button
                        onClick={() => handleToggleStatus(task.id, task.status)}
                        className="p-1 hover:bg-green-100 rounded transition-colors"
                      >
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      </button>
                      <div className="flex-1">
                        <p className="font-medium text-foreground line-through opacity-60">
                          {task.title}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(task.id)}
                      className="p-1 hover:bg-destructive/10 rounded opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
