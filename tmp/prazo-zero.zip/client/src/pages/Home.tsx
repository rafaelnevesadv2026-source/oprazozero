import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle2, Clock, TrendingUp } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useLocation } from "wouter";

export default function Home() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Fetch data
  const { data: deadlinesToday = [] } = trpc.deadlines.today.useQuery();
  const { data: deadlinesWeek = [] } = trpc.deadlines.thisWeek.useQuery();
  const { data: tasks = [] } = trpc.tasks.list.useQuery();
  const { data: notifications = [] } = trpc.notifications.list.useQuery();

  const urgentTasks = tasks.filter(t => t.priority === "critical" || t.priority === "high");
  const completedTasks = tasks.filter(t => t.status === "completed");
  const pendingTasks = tasks.filter(t => t.status === "pending");

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-300";
      case "high":
        return "bg-orange-100 text-orange-800 border-orange-300";
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      default:
        return "bg-green-100 text-green-800 border-green-300";
    }
  };

  const getStatusIcon = (priority: string) => {
    switch (priority) {
      case "critical":
        return <AlertCircle className="w-4 h-4" />;
      case "high":
        return <Clock className="w-4 h-4" />;
      default:
        return <CheckCircle2 className="w-4 h-4" />;
    }
  };

  const formatDeadlineDate = (date: Date | null) => {
    if (!date) return "Sem data";
    const daysUntil = differenceInDays(new Date(date), new Date());
    if (daysUntil === 0) return "Hoje";
    if (daysUntil === 1) return "Amanhã";
    if (daysUntil < 0) return "Vencido";
    return format(new Date(date), "dd 'de' MMMM", { locale: ptBR });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            Bem-vindo, {user?.name?.split(" ")[0]}! 👋
          </h1>
          <p className="text-foreground/60 mt-2">
            Aqui está um resumo do seu dia e dos próximos prazos
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Prazos Hoje</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{deadlinesToday.length}</div>
              <p className="text-xs text-foreground/60 mt-1">
                {deadlinesToday.filter(d => d.status === "pending").length} pendentes
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Prazos Esta Semana</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{deadlinesWeek.length}</div>
              <p className="text-xs text-foreground/60 mt-1">
                Próximos 7 dias
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Tarefas Urgentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{urgentTasks.length}</div>
              <p className="text-xs text-foreground/60 mt-1">
                Alta prioridade
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Taxa de Conclusão</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0}%
              </div>
              <p className="text-xs text-foreground/60 mt-1">
                {completedTasks.length} de {tasks.length} tarefas
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Prazos de Hoje */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Prazos de Hoje
              </CardTitle>
              <CardDescription>
                {deadlinesToday.length} prazos para hoje
              </CardDescription>
            </CardHeader>
            <CardContent>
              {deadlinesToday.length === 0 ? (
                <p className="text-foreground/60 text-center py-8">
                  Nenhum prazo para hoje. Aproveite! 🎉
                </p>
              ) : (
                <div className="space-y-3">
                  {deadlinesToday.map((deadline) => (
                    <div
                      key={deadline.id}
                      className="flex items-start justify-between p-3 bg-accent/50 rounded-lg border border-border hover:bg-accent transition-colors"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{deadline.title}</p>
                        <p className="text-sm text-foreground/60">{deadline.description}</p>
                      </div>
                      <Badge className={getPriorityColor(deadline.priority)}>
                        {deadline.priority === "critical" ? "Crítico" : 
                         deadline.priority === "high" ? "Alto" :
                         deadline.priority === "medium" ? "Médio" : "Baixo"}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Tarefas Urgentes */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-500" />
                Tarefas Urgentes
              </CardTitle>
              <CardDescription>
                {urgentTasks.length} tarefas críticas
              </CardDescription>
            </CardHeader>
            <CardContent>
              {urgentTasks.length === 0 ? (
                <p className="text-foreground/60 text-center py-8">
                  Nenhuma tarefa urgente! ✨
                </p>
              ) : (
                <div className="space-y-2">
                  {urgentTasks.slice(0, 5).map((task) => (
                    <div
                      key={task.id}
                      className="flex items-center gap-2 p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800"
                    >
                      {getStatusIcon(task.priority)}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          {task.title}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Prazos da Semana */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Prazos da Semana
            </CardTitle>
            <CardDescription>
              Próximos 7 dias
            </CardDescription>
          </CardHeader>
          <CardContent>
            {deadlinesWeek.length === 0 ? (
              <p className="text-foreground/60 text-center py-8">
                Nenhum prazo para esta semana
              </p>
            ) : (
              <div className="space-y-3">
                {deadlinesWeek.map((deadline) => (
                  <div
                    key={deadline.id}
                    className="flex items-center justify-between p-4 bg-card border border-border rounded-lg hover:border-primary transition-colors"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{deadline.title}</p>
                      <p className="text-sm text-foreground/60">
                        {deadline.category && `${deadline.category} • `}
                        {formatDeadlineDate(deadline.dueDate)}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className={getPriorityColor(deadline.priority)}>
                        {deadline.priority === "critical" ? "Crítico" : 
                         deadline.priority === "high" ? "Alto" :
                         deadline.priority === "medium" ? "Médio" : "Baixo"}
                      </Badge>
                      <Badge variant={deadline.status === "completed" ? "default" : "secondary"}>
                        {deadline.status === "completed" ? "✓ Concluído" : "Pendente"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button
                variant="outline"
                onClick={() => navigate("/tasks")}
                className="w-full"
              >
                Nova Tarefa
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate("/deadlines")}
                className="w-full"
              >
                Novo Prazo
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate("/documents")}
                className="w-full"
              >
                Upload Doc
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate("/integrations")}
                className="w-full"
              >
                Conectar APIs
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
