import { useState, useEffect } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mail, CheckCircle2, AlertCircle, Loader2, Download, Zap } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function GmailIntegration() {
  const [accessToken, setAccessToken] = useState<string>("");
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null);

  const { data: emails = [], refetch: refetchEmails, isLoading: emailsLoading } = trpc.gmail.getEmails.useQuery(
    { accessToken, maxResults: 10 },
    { enabled: !!accessToken && isConnected }
  );

  const getAuthUrlQuery = trpc.gmail.getAuthUrl.useQuery();
  const handleCallbackMutation = trpc.gmail.handleCallback.useMutation();
  const analyzeEmailMutation = trpc.gmail.analyzeAndCreateTasks.useMutation();

  const handleConnectGmail = () => {
    if (getAuthUrlQuery.data?.url) {
      window.location.href = getAuthUrlQuery.data.url;
    }
  };

  // Handle OAuth callback
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    const state = params.get("state");

    if (code) {
      setIsLoading(true);
      handleCallbackMutation.mutate(
        { code, userId: 1 }, // TODO: Get actual user ID
        {
          onSuccess: (data) => {
            setAccessToken(data.accessToken || "");
            setIsConnected(true);
            toast.success("Gmail conectado com sucesso!");
            // Clean URL
            window.history.replaceState({}, document.title, window.location.pathname);
            setIsLoading(false);
          },
          onError: (error) => {
            toast.error("Erro ao conectar Gmail");
            setIsLoading(false);
          },
        }
      );
    }
  }, []);

  const handleAnalyzeEmail = async (email: any) => {
    try {
      await analyzeEmailMutation.mutateAsync({
        accessToken,
        emailId: email.id,
        subject: email.subject,
        body: email.body,
      });
      toast.success("Email analisado! Tarefas criadas automaticamente.");
    } catch (error) {
      toast.error("Erro ao analisar email");
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Gmail</h1>
            <p className="text-foreground/60 mt-1">
              Sincronize seus emails e crie tarefas automaticamente
            </p>
          </div>
        </div>

        {/* Connection Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5" />
              Status da Conexão
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isConnected ? (
              <div className="flex items-center gap-3 p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <div className="flex-1">
                  <p className="font-medium text-green-900 dark:text-green-100">
                    Gmail Conectado
                  </p>
                  <p className="text-sm text-green-800 dark:text-green-200">
                    Você está sincronizado com sucesso
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => {
                    setIsConnected(false);
                    setAccessToken("");
                    toast.success("Gmail desconectado");
                  }}
                >
                  Desconectar
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-4 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                <AlertCircle className="w-5 h-5 text-yellow-600" />
                <div className="flex-1">
                  <p className="font-medium text-yellow-900 dark:text-yellow-100">
                    Gmail Desconectado
                  </p>
                  <p className="text-sm text-yellow-800 dark:text-yellow-200">
                    Clique em conectar para sincronizar seus emails
                  </p>
                </div>
                <Button
                  onClick={handleConnectGmail}
                  disabled={!getAuthUrlQuery.data}
                  className="gap-2"
                >
                  <Mail className="w-4 h-4" />
                  Conectar Gmail
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Emails List */}
        {isConnected && (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Emails Não Lidos ({emails.length})</span>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => refetchEmails()}
                    disabled={emailsLoading}
                    className="gap-2"
                  >
                    <Zap className="w-4 h-4" />
                    Sincronizar
                  </Button>
                </CardTitle>
                <CardDescription>
                  Seus emails mais recentes não lidos
                </CardDescription>
              </CardHeader>
              <CardContent>
                {emailsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                ) : emails.length === 0 ? (
                  <p className="text-foreground/60 text-center py-8">
                    Nenhum email não lido
                  </p>
                ) : (
                  <div className="space-y-3">
                    {emails.map((email: any) => (
                      <div
                        key={email.id}
                        className="p-4 bg-accent/50 rounded-lg border border-border hover:border-primary transition-colors group"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-medium text-foreground line-clamp-1">
                                {email.subject}
                              </h3>
                              {email.attachmentCount > 0 && (
                                <Badge variant="outline" className="gap-1">
                                  <Download className="w-3 h-3" />
                                  {email.attachmentCount}
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-foreground/60 mb-2">
                              {email.from}
                            </p>
                            <p className="text-sm text-foreground/60 line-clamp-2">
                              {email.body.substring(0, 150)}...
                            </p>
                            <p className="text-xs text-foreground/40 mt-2">
                              {email.date}
                            </p>
                          </div>
                          <Button
                            size="sm"
                            onClick={() => handleAnalyzeEmail(email)}
                            disabled={analyzeEmailMutation.isPending}
                            className="gap-2 opacity-0 group-hover:opacity-100 transition-all"
                          >
                            <Zap className="w-4 h-4" />
                            Analisar
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle>Recursos Disponíveis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                      ✓ Sincronização Automática
                    </h3>
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      Seus emails são sincronizados automaticamente a cada 5 minutos
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                    <h3 className="font-medium text-green-900 dark:text-green-100 mb-2">
                      ✓ Análise com IA
                    </h3>
                    <p className="text-sm text-green-800 dark:text-green-200">
                      IA analisa emails e cria tarefas automaticamente
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <h3 className="font-medium text-purple-900 dark:text-purple-100 mb-2">
                      ✓ Extração de Anexos
                    </h3>
                    <p className="text-sm text-purple-800 dark:text-purple-200">
                      Anexos são armazenados automaticamente no Google Drive
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
                    <h3 className="font-medium text-orange-900 dark:text-orange-100 mb-2">
                      ✓ Criação de Eventos
                    </h3>
                    <p className="text-sm text-orange-800 dark:text-orange-200">
                      Eventos são criados automaticamente na Google Agenda
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
