import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Mail, Calendar, FileText, Github, Zap, AlertCircle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

interface IntegrationItem {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  status: "connected" | "disconnected" | "pending";
  features: string[];
}

const integrations: IntegrationItem[] = [
  {
    id: "gmail",
    name: "Gmail",
    description: "Sincronize emails e extraia tarefas automaticamente",
    icon: <Mail className="w-6 h-6" />,
    color: "bg-red-100 text-red-800",
    status: "disconnected",
    features: [
      "Leitura de emails",
      "Extração de tarefas",
      "Identificação de prazos",
      "Armazenamento de anexos",
    ],
  },
  {
    id: "outlook",
    name: "Microsoft Outlook",
    description: "Conecte sua conta Outlook para sincronizar emails e calendário",
    icon: <Mail className="w-6 h-6" />,
    color: "bg-blue-100 text-blue-800",
    status: "disconnected",
    features: [
      "Sincronização de emails",
      "Sincronização de calendário",
      "Sincronização de contatos",
      "Extração de tarefas",
    ],
  },
  {
    id: "google_calendar",
    name: "Google Calendar",
    description: "Sincronize eventos e crie automaticamente compromissos",
    icon: <Calendar className="w-6 h-6" />,
    color: "bg-blue-100 text-blue-800",
    status: "disconnected",
    features: [
      "Sincronização de eventos",
      "Criação automática de eventos",
      "Lembretes inteligentes",
      "Organização por prioridade",
    ],
  },
  {
    id: "google_drive",
    name: "Google Drive",
    description: "Acesse documentos e organize por cliente ou assunto",
    icon: <FileText className="w-6 h-6" />,
    color: "bg-yellow-100 text-yellow-800",
    status: "disconnected",
    features: [
      "Acesso a documentos",
      "Sincronização automática",
      "Busca de arquivos",
      "Resumo com IA",
    ],
  },
  {
    id: "github",
    name: "GitHub",
    description: "Monitore issues, PRs e milestones dos seus repositórios",
    icon: <Github className="w-6 h-6" />,
    color: "bg-gray-100 text-gray-800",
    status: "disconnected",
    features: [
      "Monitoramento de issues",
      "Sincronização de PRs",
      "Rastreamento de milestones",
      "Alertas de deadlines",
    ],
  },
];

export default function Integrations() {
  const [selectedIntegration, setSelectedIntegration] = useState<string | null>(null);
  const [open, setOpen] = useState(false);

  const { data: connectedIntegrations = [] } = trpc.integrations.list.useQuery();

  const handleConnect = (integrationId: string) => {
    toast.info(`Conectando ${integrationId}... (em desenvolvimento)`);
  };

  const handleDisconnect = (integrationId: string) => {
    toast.info(`Desconectando ${integrationId}...`);
  };

  const isConnected = (integrationId: string) => {
    return connectedIntegrations.some(i => i.type === integrationId && i.isActive);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Integrações</h1>
          <p className="text-foreground/60 mt-1">
            Conecte suas ferramentas favoritas para automatizar o fluxo de trabalho
          </p>
        </div>

        {/* Integration Status Summary */}
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-blue-200 dark:border-blue-800">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-foreground/60">Integrações Conectadas</p>
                <p className="text-2xl font-bold text-foreground">
                  {connectedIntegrations.filter(i => i.isActive).length}/{integrations.length}
                </p>
              </div>
              <div>
                <p className="text-sm text-foreground/60">Última Sincronização</p>
                <p className="text-2xl font-bold text-foreground">Nunca</p>
              </div>
              <div>
                <p className="text-sm text-foreground/60">Status Geral</p>
                <Badge className="mt-2">
                  {connectedIntegrations.filter(i => i.isActive).length > 0 ? "Ativo" : "Inativo"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Integrations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {integrations.map((integration) => {
            const connected = isConnected(integration.id);
            return (
              <Card
                key={integration.id}
                className={`hover:border-primary transition-all ${
                  connected ? "border-green-200 dark:border-green-800" : ""
                }`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-3 rounded-lg ${integration.color}`}>
                        {integration.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{integration.name}</CardTitle>
                        <CardDescription>{integration.description}</CardDescription>
                      </div>
                    </div>
                    {connected && (
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Conectado
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Features */}
                  <div>
                    <p className="text-sm font-medium text-foreground mb-2">Recursos:</p>
                    <ul className="space-y-1">
                      {integration.features.map((feature, idx) => (
                        <li key={idx} className="text-sm text-foreground/60 flex items-center gap-2">
                          <span className="w-1 h-1 bg-foreground/40 rounded-full"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Status Alert */}
                  {!connected && (
                    <div className="flex items-start gap-2 p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                      <AlertCircle className="w-4 h-4 text-yellow-600 dark:text-yellow-500 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-yellow-800 dark:text-yellow-200">
                        Não conectado. Clique em "Conectar" para sincronizar dados.
                      </p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    {connected ? (
                      <>
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => toast.info("Sincronização em desenvolvimento")}
                        >
                          <Zap className="w-4 h-4 mr-2" />
                          Sincronizar
                        </Button>
                        <Button
                          variant="outline"
                          className="flex-1 text-destructive hover:text-destructive"
                          onClick={() => handleDisconnect(integration.id)}
                        >
                          Desconectar
                        </Button>
                      </>
                    ) : (
                      <Button
                        className="w-full"
                        onClick={() => {
                          if (integration.id === "gmail") {
                            window.location.href = "/integrations/gmail";
                          } else {
                            handleConnect(integration.id);
                          }
                        }}
                      >
                        Conectar
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Coming Soon */}
        <Card className="border-dashed">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-2xl">🚀</span>
              Em Breve
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-foreground/60">
              Mais integrações estão sendo desenvolvidas. Fique atento para:
            </p>
            <ul className="mt-3 space-y-2 text-sm text-foreground/60">
              <li>✓ Slack - Receba notificações de prazos e tarefas</li>
              <li>✓ Notion - Sincronize com seu banco de dados</li>
              <li>✓ Asana - Integre com seu gerenciador de projetos</li>
              <li>✓ Zapier - Automatize fluxos de trabalho</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
