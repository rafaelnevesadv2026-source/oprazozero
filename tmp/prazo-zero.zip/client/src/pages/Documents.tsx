import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { FileText, Plus, Trash2, Download, Search } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function Documents() {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    client: "",
  });

  const { data: documents = [], refetch } = trpc.documents.list.useQuery();

  const filteredDocuments = documents.filter(doc =>
    doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.client?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreate = async () => {
    if (!formData.title.trim()) {
      toast.error("Título é obrigatório");
      return;
    }

    // TODO: Implement file upload to S3
    toast.info("Upload de arquivos será implementado em breve");
  };

  const getCategoryColor = (category?: string) => {
    switch (category) {
      case "contract":
        return "bg-blue-100 text-blue-800";
      case "invoice":
        return "bg-green-100 text-green-800";
      case "report":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryLabel = (category?: string) => {
    switch (category) {
      case "contract":
        return "Contrato";
      case "invoice":
        return "Fatura";
      case "report":
        return "Relatório";
      default:
        return "Outro";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Documentos</h1>
            <p className="text-foreground/60 mt-1">Organize e armazene seus documentos importantes</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Novo Documento
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Upload de Documento</DialogTitle>
                <DialogDescription>
                  Adicione um novo documento ao repositório
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Título</label>
                  <Input
                    placeholder="Título do documento"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Descrição</label>
                  <Textarea
                    placeholder="Descrição do documento"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Categoria</label>
                    <Input
                      placeholder="Ex: contract, invoice"
                      value={formData.category}
                      onChange={(e) =>
                        setFormData({ ...formData, category: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Cliente/Assunto</label>
                    <Input
                      placeholder="Nome do cliente"
                      value={formData.client}
                      onChange={(e) =>
                        setFormData({ ...formData, client: e.target.value })
                      }
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Arquivo</label>
                  <Input type="file" disabled placeholder="Selecione um arquivo" />
                  <p className="text-xs text-foreground/60 mt-2">
                    Upload de arquivos será implementado em breve
                  </p>
                </div>
                <Button
                  onClick={handleCreate}
                  className="w-full"
                  disabled
                >
                  Upload (Em desenvolvimento)
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <Card>
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-foreground/40" />
              <Input
                placeholder="Buscar documentos por título ou cliente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Documents Grid */}
        {filteredDocuments.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12">
              <div className="text-center">
                <FileText className="w-12 h-12 text-foreground/20 mx-auto mb-4" />
                <p className="text-foreground/60">
                  {searchTerm ? "Nenhum documento encontrado" : "Nenhum documento armazenado"}
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDocuments.map((doc) => (
              <Card key={doc.id} className="hover:border-primary transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base line-clamp-2">
                        {doc.title}
                      </CardTitle>
                      {doc.client && (
                        <CardDescription className="mt-1">
                          {doc.client}
                        </CardDescription>
                      )}
                    </div>
                    <FileText className="w-5 h-5 text-foreground/40 flex-shrink-0" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {doc.description && (
                    <p className="text-sm text-foreground/60 line-clamp-2">
                      {doc.description}
                    </p>
                  )}
                  <div className="flex items-center gap-2 flex-wrap">
                    {doc.category && (
                      <Badge className={getCategoryColor(doc.category)}>
                        {getCategoryLabel(doc.category)}
                      </Badge>
                    )}
                    {doc.summary && (
                      <Badge variant="outline">Resumido</Badge>
                    )}
                  </div>
                  <p className="text-xs text-foreground/40">
                    {doc.uploadedAt && format(new Date(doc.uploadedAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                  </p>
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-2"
                      disabled
                    >
                      <Download className="w-3 h-3" />
                      Download
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      disabled
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
