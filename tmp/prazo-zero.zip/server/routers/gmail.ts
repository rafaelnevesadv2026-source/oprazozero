import { router, protectedProcedure, publicProcedure } from "../_core/trpc";
import { z } from "zod";
import {
  getGoogleAuthUrl,
  getTokenFromCode,
  getEmails,
  getEmailAttachments,
  createCalendarEvent,
  listDriveFiles,
} from "../integrations/gmail";
import { getDb } from "../db";
import { analyzeEmailContent } from "../ai-analyzer";

export const gmailRouter = router({
  // Get Google OAuth login URL
  getAuthUrl: publicProcedure.query(() => {
    return {
      url: getGoogleAuthUrl(),
    };
  }),

  // Handle OAuth callback
  handleCallback: publicProcedure
    .input(
      z.object({
        code: z.string(),
        userId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const tokens = await getTokenFromCode(input.code);

        // Save tokens to database
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        // TODO: Save integration tokens to database
        // For now, just return the tokens
        return {
          success: true,
          accessToken: tokens.access_token,
          refreshToken: tokens.refresh_token,
          expiresIn: tokens.expiry_date,
        };
      } catch (error) {
        console.error("Error handling OAuth callback:", error);
        throw error;
      }
    }),

  // Get unread emails
  getEmails: protectedProcedure
    .input(
      z.object({
        accessToken: z.string(),
        maxResults: z.number().optional().default(10),
      })
    )
    .query(async ({ input }) => {
      try {
        const emails = await getEmails(input.accessToken, input.maxResults);
        return emails;
      } catch (error) {
        console.error("Error fetching emails:", error);
        throw error;
      }
    }),

  // Analyze email and create tasks
  analyzeAndCreateTasks: protectedProcedure
    .input(
      z.object({
        accessToken: z.string(),
        emailId: z.string(),
        subject: z.string(),
        body: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // Analyze email with AI
        const analysis = await analyzeEmailContent(input.subject, input.body);

        // TODO: Create tasks and deadlines from analysis
        // For now, just return the analysis
        return {
          success: true,
          analysis,
        };
      } catch (error) {
        console.error("Error analyzing email:", error);
        throw error;
      }
    }),

  // Get email attachments
  getAttachments: protectedProcedure
    .input(
      z.object({
        accessToken: z.string(),
        messageId: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const attachments = await getEmailAttachments(
          input.accessToken,
          input.messageId
        );
        return attachments;
      } catch (error) {
        console.error("Error fetching attachments:", error);
        throw error;
      }
    }),

  // Create calendar event
  createEvent: protectedProcedure
    .input(
      z.object({
        accessToken: z.string(),
        summary: z.string(),
        description: z.string().optional(),
        startDateTime: z.string(),
        endDateTime: z.string(),
        timeZone: z.string().default("America/Sao_Paulo"),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const event = await createCalendarEvent(input.accessToken, {
          summary: input.summary,
          description: input.description,
          start: {
            dateTime: input.startDateTime,
            timeZone: input.timeZone,
          },
          end: {
            dateTime: input.endDateTime,
            timeZone: input.timeZone,
          },
        });

        return {
          success: true,
          event,
        };
      } catch (error) {
        console.error("Error creating event:", error);
        throw error;
      }
    }),

  // List Google Drive files
  listDriveFiles: protectedProcedure
    .input(
      z.object({
        accessToken: z.string(),
        maxResults: z.number().optional().default(10),
      })
    )
    .query(async ({ input }) => {
      try {
        const files = await listDriveFiles(input.accessToken, input.maxResults);
        return files;
      } catch (error) {
        console.error("Error listing drive files:", error);
        throw error;
      }
    }),
});
