import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as any,
  };

  return { ctx };
}

describe("gmail integration", () => {
  it("should return auth URL", async () => {
    const caller = appRouter.createCaller({} as any);
    const result = await caller.gmail.getAuthUrl();

    expect(result).toHaveProperty("url");
    expect(result.url).toContain("https://accounts.google.com");
  });

  it("should handle OAuth callback", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Mock the token exchange (in real scenario, this would call Google's API)
    // For now, we're just testing the endpoint exists and accepts the right params
    try {
      const result = await caller.gmail.handleCallback({
        code: "test-code",
        userId: 1,
      });

      // The test might fail due to invalid code, but that's expected
      // We're just verifying the endpoint structure
    } catch (error) {
      // Expected to fail with invalid code
      expect(error).toBeDefined();
    }
  });

  it("should require authentication for email operations", async () => {
    const caller = appRouter.createCaller({} as any);

    try {
      await caller.gmail.getEmails({
        accessToken: "test-token",
        maxResults: 10,
      });
      // Should fail without auth context
      expect(true).toBe(false);
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should require authentication for attachment operations", async () => {
    const caller = appRouter.createCaller({} as any);

    try {
      await caller.gmail.getAttachments({
        accessToken: "test-token",
        messageId: "test-id",
      });
      // Should fail without auth context
      expect(true).toBe(false);
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should require authentication for creating events", async () => {
    const caller = appRouter.createCaller({} as any);

    try {
      await caller.gmail.createEvent({
        accessToken: "test-token",
        summary: "Test Event",
        startDateTime: new Date().toISOString(),
        endDateTime: new Date().toISOString(),
      });
      // Should fail without auth context
      expect(true).toBe(false);
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should require authentication for listing drive files", async () => {
    const caller = appRouter.createCaller({} as any);

    try {
      await caller.gmail.listDriveFiles({
        accessToken: "test-token",
        maxResults: 10,
      });
      // Should fail without auth context
      expect(true).toBe(false);
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });
});
