import { eq, and, gte, lte, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, tasks, deadlines, documents, emails, integrations, notifications, calendarEvents, githubIssues, syncLogs } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ TASKS ============

export async function getUserTasks(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks).where(eq(tasks.userId, userId)).orderBy(desc(tasks.priority), asc(tasks.dueDate));
}

export async function getTasksByStatus(userId: number, status: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.status, status as any))).orderBy(asc(tasks.dueDate));
}

export async function createTask(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(tasks).values({ userId, ...data });
  return result;
}

export async function updateTask(taskId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(tasks).set(data).where(eq(tasks.id, taskId));
}

export async function deleteTask(taskId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(tasks).where(eq(tasks.id, taskId));
}

// ============ DEADLINES ============

export async function getUserDeadlines(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(deadlines).where(eq(deadlines.userId, userId)).orderBy(asc(deadlines.dueDate));
}

export async function getDeadlinesToday(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  return db.select().from(deadlines).where(
    and(
      eq(deadlines.userId, userId),
      gte(deadlines.dueDate, today),
      lte(deadlines.dueDate, tomorrow)
    )
  ).orderBy(asc(deadlines.dueDate));
}

export async function getDeadlinesThisWeek(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const today = new Date();
  const weekEnd = new Date(today);
  weekEnd.setDate(weekEnd.getDate() + 7);
  
  return db.select().from(deadlines).where(
    and(
      eq(deadlines.userId, userId),
      gte(deadlines.dueDate, today),
      lte(deadlines.dueDate, weekEnd)
    )
  ).orderBy(asc(deadlines.dueDate));
}

export async function createDeadline(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(deadlines).values({ userId, ...data });
}

export async function updateDeadline(deadlineId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(deadlines).set(data).where(eq(deadlines.id, deadlineId));
}

// ============ DOCUMENTS ============

export async function getUserDocuments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documents).where(eq(documents.userId, userId)).orderBy(desc(documents.uploadedAt));
}

export async function getDocumentsByClient(userId: number, client: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documents).where(and(eq(documents.userId, userId), eq(documents.client, client))).orderBy(desc(documents.uploadedAt));
}

export async function createDocument(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(documents).values({ userId, ...data });
}

export async function updateDocument(documentId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(documents).set(data).where(eq(documents.id, documentId));
}

// ============ EMAILS ============

export async function getUserEmails(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(emails).where(eq(emails.userId, userId)).orderBy(desc(emails.receivedAt));
}

export async function createEmail(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(emails).values({ userId, ...data });
}

export async function updateEmail(emailId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(emails).set(data).where(eq(emails.id, emailId));
}

// ============ INTEGRATIONS ============

export async function getUserIntegrations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(integrations).where(eq(integrations.userId, userId));
}

export async function getIntegrationByType(userId: number, type: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(integrations).where(and(eq(integrations.userId, userId), eq(integrations.type, type as any))).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createIntegration(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(integrations).values({ userId, ...data });
}

export async function updateIntegration(integrationId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(integrations).set(data).where(eq(integrations.id, integrationId));
}

// ============ NOTIFICATIONS ============

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.sentAt));
}

export async function createNotification(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(notifications).values({ userId, ...data });
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(notifications).set({ isRead: true }).where(eq(notifications.id, notificationId));
}

// ============ CALENDAR EVENTS ============

export async function getUserCalendarEvents(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(calendarEvents).where(eq(calendarEvents.userId, userId)).orderBy(asc(calendarEvents.startTime));
}

export async function createCalendarEvent(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(calendarEvents).values({ userId, ...data });
}

// ============ GITHUB ISSUES ============

export async function getUserGitHubIssues(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(githubIssues).where(eq(githubIssues.userId, userId)).orderBy(desc(githubIssues.syncedAt));
}

export async function createGitHubIssue(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(githubIssues).values({ userId, ...data });
}

// ============ SYNC LOGS ============

export async function createSyncLog(userId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(syncLogs).values({ userId, ...data });
}

export async function getLastSyncLog(userId: number, integrationType: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(syncLogs).where(
    and(eq(syncLogs.userId, userId), eq(syncLogs.integrationType, integrationType))
  ).orderBy(desc(syncLogs.lastSyncAt)).limit(1);
  return result.length > 0 ? result[0] : null;
}
