import { invokeLLM } from "./_core/llm";

export interface ExtractedData {
  tasks: Array<{
    title: string;
    description?: string;
    priority: "low" | "medium" | "high" | "critical";
    dueDate?: string;
  }>;
  deadlines: Array<{
    title: string;
    description?: string;
    dueDate: string;
    priority: "low" | "medium" | "high" | "critical";
    category?: string;
  }>;
  payments: Array<{
    description: string;
    amount?: string;
    dueDate?: string;
  }>;
  summary: string;
}

export async function analyzeEmailContent(subject: string, body: string): Promise<ExtractedData> {
  const prompt = `Analyze the following email and extract structured information.

Subject: ${subject}
Body: ${body}

Extract:
1. Tasks: Any actionable items or to-dos mentioned
2. Deadlines: Any dates, deadlines, or time-sensitive information
3. Payments: Any payment-related information (amounts, due dates)
4. Summary: A brief summary of the email (max 2 sentences)

For each task and deadline, assign a priority:
- critical: Urgent, time-sensitive, high impact
- high: Important, needs attention soon
- medium: Standard priority
- low: Can be done later

Return the response as a valid JSON object with the structure:
{
  "tasks": [{"title": string, "description": string, "priority": string, "dueDate": string}],
  "deadlines": [{"title": string, "description": string, "dueDate": string, "priority": string, "category": string}],
  "payments": [{"description": string, "amount": string, "dueDate": string}],
  "summary": string
}`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are an expert at analyzing emails and extracting actionable information. Always return valid JSON.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "email_analysis",
          strict: true,
          schema: {
            type: "object",
            properties: {
              tasks: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    description: { type: "string" },
                    priority: { type: "string", enum: ["low", "medium", "high", "critical"] },
                    dueDate: { type: "string" },
                  },
                  required: ["title", "priority"],
                },
              },
              deadlines: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    description: { type: "string" },
                    dueDate: { type: "string" },
                    priority: { type: "string", enum: ["low", "medium", "high", "critical"] },
                    category: { type: "string" },
                  },
                  required: ["title", "dueDate", "priority"],
                },
              },
              payments: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    description: { type: "string" },
                    amount: { type: "string" },
                    dueDate: { type: "string" },
                  },
                  required: ["description"],
                },
              },
              summary: { type: "string" },
            },
            required: ["tasks", "deadlines", "payments", "summary"],
            additionalProperties: false,
          },
        },
      },
    });

    const responseContent = response.choices[0]?.message.content;
    if (!responseContent || typeof responseContent !== "string") {
      throw new Error("No response from LLM");
    }

    const parsed = JSON.parse(responseContent);
    return {
      tasks: parsed.tasks || [],
      deadlines: parsed.deadlines || [],
      payments: parsed.payments || [],
      summary: parsed.summary || "",
    };
  } catch (error) {
    console.error("Error analyzing email:", error);
    return {
      tasks: [],
      deadlines: [],
      payments: [],
      summary: "Erro ao analisar email com IA",
    };
  }
}

export async function summarizeDocument(title: string, documentContent: string): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are an expert at summarizing documents. Provide a concise, clear summary in Portuguese.",
        },
        {
          role: "user",
          content: `Summarize the following document in 2-3 sentences:

Title: ${title}
Content: ${documentContent.substring(0, 2000)}`,
        },
      ],
    });

    const responseContent = response.choices[0]?.message.content;
    const summary = typeof responseContent === "string" ? responseContent : "Resumo não disponível";
    return summary;
  } catch (error) {
    console.error("Error summarizing document:", error);
    return "Erro ao resumir documento com IA";
  }
}

export async function suggestPriority(title: string, description: string): Promise<"low" | "medium" | "high" | "critical"> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are an expert at assessing task priority. Return only one word: low, medium, high, or critical.",
        },
        {
          role: "user",
          content: `Based on the title and description, what priority should this task have?

Title: ${title}
Description: ${description}

Return only: low, medium, high, or critical`,
        },
      ],
    });

    const responseContent = response.choices[0]?.message.content;
    const priority = typeof responseContent === "string" ? responseContent.toLowerCase().trim() : "";
    if (["low", "medium", "high", "critical"].includes(priority)) {
      return priority as "low" | "medium" | "high" | "critical";
    }
    return "medium";
  } catch (error) {
    console.error("Error suggesting priority:", error);
    return "medium";
  }
}
