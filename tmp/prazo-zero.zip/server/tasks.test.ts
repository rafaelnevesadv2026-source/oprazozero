import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext; clearedCookies: any[] } {
  const clearedCookies: any[] = [];

  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };

  return { ctx, clearedCookies };
}

describe("tasks router", () => {
  it("should list tasks for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // This will return an empty array since we don't have test data
    const tasks = await caller.tasks.list();
    expect(Array.isArray(tasks)).toBe(true);
  });

  it("should create a task with valid input", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.tasks.create({
      title: "Test Task",
      description: "This is a test task",
      priority: "high",
      dueDate: new Date("2026-12-31"),
    });

    expect(result).toBeDefined();
  });

  it("should get tasks by status", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const tasks = await caller.tasks.getByStatus({ status: "pending" });
    expect(Array.isArray(tasks)).toBe(true);
  });
});

describe("deadlines router", () => {
  it("should list deadlines for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const deadlines = await caller.deadlines.list();
    expect(Array.isArray(deadlines)).toBe(true);
  });

  it("should get deadlines for today", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const deadlines = await caller.deadlines.today();
    expect(Array.isArray(deadlines)).toBe(true);
  });

  it("should get deadlines for this week", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const deadlines = await caller.deadlines.thisWeek();
    expect(Array.isArray(deadlines)).toBe(true);
  });

  it("should create a deadline with valid input", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.deadlines.create({
      title: "Test Deadline",
      description: "This is a test deadline",
      dueDate: new Date("2026-12-31"),
      priority: "critical",
      category: "legal",
    });

    expect(result).toBeDefined();
  });
});

describe("documents router", () => {
  it("should list documents for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const documents = await caller.documents.list();
    expect(Array.isArray(documents)).toBe(true);
  });

  it("should get documents by client", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const documents = await caller.documents.getByClient({ client: "Test Client" });
    expect(Array.isArray(documents)).toBe(true);
  });
});

describe("integrations router", () => {
  it("should list integrations for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const integrations = await caller.integrations.list();
    expect(Array.isArray(integrations)).toBe(true);
  });

  it("should get integration by type", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const integration = await caller.integrations.getByType({ type: "gmail" });
    // Integration might be null if not connected
    expect(integration === null || typeof integration === "object").toBe(true);
  });
});

describe("notifications router", () => {
  it("should list notifications for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const notifications = await caller.notifications.list();
    expect(Array.isArray(notifications)).toBe(true);
  });
});

describe("calendar events router", () => {
  it("should list calendar events for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const events = await caller.calendarEvents.list();
    expect(Array.isArray(events)).toBe(true);
  });
});

describe("github issues router", () => {
  it("should list github issues for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const issues = await caller.githubIssues.list();
    expect(Array.isArray(issues)).toBe(true);
  });
});
