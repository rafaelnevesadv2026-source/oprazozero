import { google } from "googleapis";
import { ENV } from "../_core/env";

const oauth2Client = new google.auth.OAuth2(
  ENV.googleClientId,
  ENV.googleClientSecret,
  ENV.googleRedirectUri
);

export function getGoogleAuthUrl(): string {
  const scopes = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/drive.readonly",
  ];

  return oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: scopes,
    prompt: "consent",
  });
}

export async function getTokenFromCode(code: string) {
  try {
    const { tokens } = await oauth2Client.getToken(code);
    return tokens;
  } catch (error) {
    console.error("Error getting token from code:", error);
    throw error;
  }
}

export async function getGmailClient(accessToken: string) {
  oauth2Client.setCredentials({
    access_token: accessToken,
  });

  return google.gmail({ version: "v1", auth: oauth2Client });
}

export async function getCalendarClient(accessToken: string) {
  oauth2Client.setCredentials({
    access_token: accessToken,
  });

  return google.calendar({ version: "v3", auth: oauth2Client });
}

export async function getDriveClient(accessToken: string) {
  oauth2Client.setCredentials({
    access_token: accessToken,
  });

  return google.drive({ version: "v3", auth: oauth2Client });
}

export async function getEmails(accessToken: string, maxResults: number = 10) {
  try {
    const gmail = await getGmailClient(accessToken);

    const response = await gmail.users.messages.list({
      userId: "me",
      maxResults,
      q: "is:unread",
    });

    const messages = response.data.messages || [];

    // Get full message details
    const emailDetails = await Promise.all(
      messages.map(async (msg: any) => {
        const message = await gmail.users.messages.get({
          userId: "me",
          id: msg.id!,
          format: "full",
        });

        return parseEmailMessage(message.data);
      })
    );

    return emailDetails;
  } catch (error) {
    console.error("Error fetching emails:", error);
    throw error;
  }
}

export async function getEmailAttachments(
  accessToken: string,
  messageId: string
) {
  try {
    const gmail = await getGmailClient(accessToken);

    const message = await gmail.users.messages.get({
      userId: "me",
      id: messageId,
      format: "full",
    });

    const attachments = [];
    const parts = message.data.payload?.parts || [];

    for (const part of parts) {
      if (part.filename && part.body?.attachmentId) {
        attachments.push({
          filename: part.filename,
          mimeType: part.mimeType,
          attachmentId: part.body.attachmentId,
          size: part.body.size,
        });
      }
    }

    return attachments;
  } catch (error) {
    console.error("Error fetching attachments:", error);
    throw error;
  }
}

export async function downloadAttachment(
  accessToken: string,
  messageId: string,
  attachmentId: string
) {
  try {
    const gmail = await getGmailClient(accessToken);

    const attachment = await gmail.users.messages.attachments.get({
      userId: "me",
      messageId,
      id: attachmentId,
    });

    return attachment.data;
  } catch (error) {
    console.error("Error downloading attachment:", error);
    throw error;
  }
}

interface ParsedEmail {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  date: string;
  body: string;
  attachmentCount: number;
}

function parseEmailMessage(message: any): ParsedEmail {
  const headers = message.payload?.headers || [];
  const getHeader = (name: string) => {
    const header = headers.find((h: any) => h.name === name);
    return header?.value || "";
  };

  let body = "";
  if (message.payload?.parts) {
    const textPart = message.payload.parts.find(
      (p: any) => p.mimeType === "text/plain"
    );
    if (textPart?.body?.data) {
      body = Buffer.from(textPart.body.data, "base64").toString("utf-8");
    }
  } else if (message.payload?.body?.data) {
    body = Buffer.from(message.payload.body.data, "base64").toString("utf-8");
  }

  const attachmentCount = (message.payload?.parts || []).filter(
    (p: any) => p.filename
  ).length;

  return {
    id: message.id,
    threadId: message.threadId,
    subject: getHeader("Subject"),
    from: getHeader("From"),
    to: getHeader("To"),
    date: getHeader("Date"),
    body,
    attachmentCount,
  };
}

export async function createCalendarEvent(
  accessToken: string,
  event: {
    summary: string;
    description?: string;
    start: { dateTime: string; timeZone: string };
    end: { dateTime: string; timeZone: string };
  }
) {
  try {
    const calendar = await getCalendarClient(accessToken);

    const response = await calendar.events.insert({
      calendarId: "primary",
      requestBody: event,
    });

    return response.data;
  } catch (error) {
    console.error("Error creating calendar event:", error);
    throw error;
  }
}

export async function listDriveFiles(
  accessToken: string,
  maxResults: number = 10
) {
  try {
    const drive = await getDriveClient(accessToken);

    const response = await drive.files.list({
      pageSize: maxResults,
      fields: "files(id, name, mimeType, createdTime, modifiedTime)",
      q: "trashed=false",
    });

    return response.data.files || [];
  } catch (error) {
    console.error("Error listing drive files:", error);
    throw error;
  }
}
