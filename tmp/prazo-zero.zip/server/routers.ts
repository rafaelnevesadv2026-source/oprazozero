import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { gmailRouter } from "./routers/gmail";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ TASKS ============
  tasks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserTasks(ctx.user.id);
    }),

    getByStatus: protectedProcedure
      .input(z.object({ status: z.string() }))
      .query(async ({ ctx, input }) => {
        return db.getTasksByStatus(ctx.user.id, input.status);
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).default("medium"),
        dueDate: z.date().optional(),
        source: z.string().optional(),
        sourceId: z.string().optional(),
        assignedTo: z.string().optional(),
        tags: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createTask(ctx.user.id, {
          ...input,
          tags: input.tags ? JSON.stringify(input.tags) : null,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        status: z.enum(["pending", "in_progress", "completed", "cancelled"]).optional(),
        dueDate: z.date().optional(),
        completedAt: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateTask(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.deleteTask(input.id);
      }),
  }),

  // ============ DEADLINES ============
  deadlines: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserDeadlines(ctx.user.id);
    }),

    today: protectedProcedure.query(async ({ ctx }) => {
      return db.getDeadlinesToday(ctx.user.id);
    }),

    thisWeek: protectedProcedure.query(async ({ ctx }) => {
      return db.getDeadlinesThisWeek(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        dueDate: z.date(),
        priority: z.enum(["low", "medium", "high", "critical"]).default("medium"),
        category: z.string().optional(),
        source: z.string().optional(),
        sourceId: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createDeadline(ctx.user.id, input);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        dueDate: z.date().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        status: z.enum(["pending", "completed", "overdue"]).optional(),
        completedAt: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateDeadline(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return { success: true };
      }),
  }),

  // ============ DOCUMENTS ============
  documents: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserDocuments(ctx.user.id);
    }),

    getByClient: protectedProcedure
      .input(z.object({ client: z.string() }))
      .query(async ({ ctx, input }) => {
        return db.getDocumentsByClient(ctx.user.id, input.client);
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        fileKey: z.string(),
        fileUrl: z.string(),
        fileName: z.string(),
        mimeType: z.string().optional(),
        fileSize: z.number().optional(),
        category: z.string().optional(),
        client: z.string().optional(),
        tags: z.array(z.string()).optional(),
        summary: z.string().optional(),
        source: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createDocument(ctx.user.id, {
          ...input,
          tags: input.tags ? JSON.stringify(input.tags) : null,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        category: z.string().optional(),
        client: z.string().optional(),
        tags: z.array(z.string()).optional(),
        summary: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, tags, ...data } = input;
        return db.updateDocument(id, {
          ...data,
          tags: tags ? JSON.stringify(tags) : undefined,
        });
      }),
  }),

  // ============ INTEGRATIONS ============
  integrations: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserIntegrations(ctx.user.id);
    }),

    getByType: protectedProcedure
      .input(z.object({ type: z.string() }))
      .query(async ({ ctx, input }) => {
        return db.getIntegrationByType(ctx.user.id, input.type);
      }),

    create: protectedProcedure
      .input(z.object({
        type: z.enum(["gmail", "outlook", "google_drive", "google_calendar", "github"]),
        accessToken: z.string().optional(),
        refreshToken: z.string().optional(),
        expiresAt: z.date().optional(),
        metadata: z.record(z.string(), z.any()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createIntegration(ctx.user.id, {
          ...input,
          metadata: input.metadata ? JSON.stringify(input.metadata) : null,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        accessToken: z.string().optional(),
        refreshToken: z.string().optional(),
        expiresAt: z.date().optional(),
        isActive: z.boolean().optional(),
        metadata: z.record(z.string(), z.any()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, metadata, ...data } = input;
        return db.updateIntegration(id, {
          ...data,
          metadata: metadata ? JSON.stringify(metadata) : undefined,
        });
      }),
  }),

  // ============ NOTIFICATIONS ============
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserNotifications(ctx.user.id);
    }),

    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return db.markNotificationAsRead(input.id);
      }),
  }),

  // ============ CALENDAR EVENTS ============
  calendarEvents: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserCalendarEvents(ctx.user.id);
    }),
  }),

  // ============ GITHUB ISSUES ============
  githubIssues: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserGitHubIssues(ctx.user.id);
    }),
  }),

  // ============ GMAIL INTEGRATION ============
  gmail: gmailRouter,
});

export type AppRouter = typeof appRouter;
