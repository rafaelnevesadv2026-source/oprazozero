# Prazo Zero - TODO

## Autenticação e Estrutura Base
- [x] Inicializar projeto com scaffold web-db-user
- [x] Configurar autenticação OAuth do Manus
- [x] Página de login e logout
- [x] Proteção de rotas autenticadas

## Banco de Dados
- [x] Criar tabelas para Tarefas (tasks)
- [x] Criar tabelas para Prazos (deadlines)
- [x] Criar tabelas para Documentos (documents)
- [x] Criar tabelas para Integrações (integrations)
- [x] Criar tabelas para Notificações (notifications)
- [x] Criar tabelas para Eventos de Agenda (calendar_events)
- [x] Executar migrações SQL

## Painel Principal (Dashboard)
- [x] Desenvolver layout do dashboard com sidebar
- [x] Exibir prazos do dia
- [x] Exibir prazos da semana
- [x] Exibir tarefas urgentes organizadas por prioridade
- [x] Implementar filtros e busca
- [x] Adicionar cards com estatísticas

## Integrações Externas
- [ ] Integração com Gmail (leitura de emails)
- [ ] Integração com Outlook (leitura de emails e calendário)
- [ ] Integração com Google Drive (acesso a documentos)
- [ ] Integração com Google Agenda (sincronização de eventos)
- [ ] Integração com GitHub (monitoramento de issues e milestones)
- [ ] Criar interface para conectar/desconectar integrações

## Sistema de IA e Análise Inteligente
- [x] Implementar LLM para análise de emails
- [x] Extrair datas automaticamente de textos
- [x] Extrair tarefas automaticamente de emails
- [x] Identificar pagamentos em emails
- [x] Gerar resumos automáticos de documentos
- [x] Gerar resumos automáticos de emails
- [x] Sugerir prioridades baseado em conteúdo

## Gerenciamento de Documentos
- [x] Página de repositório de documentos
- [ ] Upload de documentos para S3
- [x] Organização por cliente ou assunto
- [x] Busca de documentos
- [ ] Visualização de documentos
- [ ] Armazenamento de anexos de emails

## Notificações e Alertas
- [x] Sistema de notificações em tempo real
- [ ] Alertas para prazos críticos
- [ ] Lembretes automáticos
- [ ] Email notifications para eventos importantes
- [ ] Integração com sistema de notificações do Manus

## Agenda Automática
- [ ] Criar eventos automaticamente na Google Agenda
- [ ] Sincronizar eventos do Google Agenda
- [ ] Organizar eventos por prioridade
- [ ] Visualizar calendário integrado

## Testes
- [x] Testes unitários para procedimentos tRPC
- [ ] Testes de integração com APIs externas
- [x] Testes do dashboard
- [ ] Testes do sistema de IA

## Deploy e Finalização
- [ ] Otimizar performance
- [ ] Verificar segurança
- [ ] Criar checkpoint final
- [ ] Entregar ao usuário


## Integrações - Implementação Completa
- [x] Configurar credenciais OAuth2 para Gmail
- [ ] Implementar armazenamento seguro de tokens no banco de dados
- [x] Implementar autenticação OAuth2 para Gmail
- [x] Implementar leitura de emails do Gmail
- [ ] Implementar sincronização automática de emails
- [x] Implementar processamento de emails com IA
- [x] Implementar criação automática de tarefas a partir de emails
- [x] Implementar integração com Google Agenda (leitura e criação de eventos)
- [x] Implementar integração com Google Drive (listagem e leitura de documentos)
- [ ] Implementar integração com Outlook (OAuth2 e sincronização)
- [ ] Implementar integração com GitHub (monitoramento de issues e PRs)
- [ ] Implementar sincronização automática periódica
- [ ] Implementar webhooks para atualizações em tempo real
- [x] Testar integração com Gmail
- [ ] Documentar processo de configuração das APIs
