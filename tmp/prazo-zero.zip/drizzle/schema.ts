import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Integrations table - stores connection info for external services
 */
export const integrations = mysqlTable("integrations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["gmail", "outlook", "google_drive", "google_calendar", "github"]).notNull(),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  expiresAt: timestamp("expiresAt"),
  isActive: boolean("isActive").default(true).notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Integration = typeof integrations.$inferSelect;
export type InsertIntegration = typeof integrations.$inferInsert;

/**
 * Tasks table - stores individual tasks extracted from emails and documents
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "cancelled"]).default("pending").notNull(),
  dueDate: timestamp("dueDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completedAt"),
  source: varchar("source", { length: 50 }), // "email", "document", "manual"
  sourceId: varchar("sourceId", { length: 255 }), // Reference to email or document
  assignedTo: varchar("assignedTo", { length: 320 }),
  tags: json("tags"), // Array of tags for organization
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Deadlines table - stores important deadlines and dates
 */
export const deadlines = mysqlTable("deadlines", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: timestamp("dueDate").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  category: varchar("category", { length: 100 }), // "legal", "payment", "project", "event"
  status: mysqlEnum("status", ["pending", "completed", "overdue"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completedAt"),
  source: varchar("source", { length: 50 }), // "email", "document", "calendar", "github"
  sourceId: varchar("sourceId", { length: 255 }), // Reference to source
  notificationSent: boolean("notificationSent").default(false).notNull(),
});

export type Deadline = typeof deadlines.$inferSelect;
export type InsertDeadline = typeof deadlines.$inferInsert;

/**
 * Documents table - stores document metadata and references
 */
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  fileKey: varchar("fileKey", { length: 500 }).notNull(), // S3 file key
  fileUrl: text("fileUrl").notNull(), // S3 public URL
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"), // in bytes
  category: varchar("category", { length: 100 }), // "contract", "invoice", "report", "other"
  client: varchar("client", { length: 255 }), // Client or subject name
  tags: json("tags"), // Array of tags
  summary: text("summary"), // AI-generated summary
  extractedData: json("extractedData"), // Extracted dates, amounts, etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  source: varchar("source", { length: 50 }), // "email", "google_drive", "manual"
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

/**
 * Emails table - stores processed email data
 */
export const emails = mysqlTable("emails", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  externalId: varchar("externalId", { length: 255 }).notNull().unique(), // Gmail/Outlook message ID
  from: varchar("from", { length: 320 }).notNull(),
  to: text("to"), // JSON array or comma-separated
  subject: text("subject").notNull(),
  body: text("body"),
  summary: text("summary"), // AI-generated summary
  receivedAt: timestamp("receivedAt").notNull(),
  processedAt: timestamp("processedAt").defaultNow().notNull(),
  extractedTasks: json("extractedTasks"), // Array of extracted tasks
  extractedDeadlines: json("extractedDeadlines"), // Array of extracted deadlines
  extractedPayments: json("extractedPayments"), // Array of extracted payment info
  hasAttachments: boolean("hasAttachments").default(false).notNull(),
  attachmentKeys: json("attachmentKeys"), // Array of S3 file keys
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Email = typeof emails.$inferSelect;
export type InsertEmail = typeof emails.$inferInsert;

/**
 * Calendar Events table - stores synced calendar events
 */
export const calendarEvents = mysqlTable("calendar_events", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  externalId: varchar("externalId", { length: 255 }).notNull(), // Google Calendar event ID
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("startTime").notNull(),
  endTime: timestamp("endTime").notNull(),
  location: varchar("location", { length: 255 }),
  attendees: json("attendees"), // Array of attendee emails
  priority: mysqlEnum("priority", ["low", "medium", "high"]).default("medium").notNull(),
  source: varchar("source", { length: 50 }), // "google_calendar", "outlook", "manual"
  linkedTaskId: int("linkedTaskId"), // Link to task if created from task
  linkedDeadlineId: int("linkedDeadlineId"), // Link to deadline if created from deadline
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  syncedAt: timestamp("syncedAt").defaultNow().notNull(),
});

export type CalendarEvent = typeof calendarEvents.$inferSelect;
export type InsertCalendarEvent = typeof calendarEvents.$inferInsert;

/**
 * GitHub Issues table - stores synced GitHub issues and milestones
 */
export const githubIssues = mysqlTable("github_issues", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  repositoryName: varchar("repositoryName", { length: 255 }).notNull(),
  externalId: varchar("externalId", { length: 255 }).notNull(), // GitHub issue number
  title: text("title").notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["open", "closed"]).notNull(),
  priority: varchar("priority", { length: 50 }), // From labels
  dueDate: timestamp("dueDate"),
  assignees: json("assignees"), // Array of GitHub usernames
  labels: json("labels"), // Array of GitHub labels
  url: text("url").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  syncedAt: timestamp("syncedAt").defaultNow().notNull(),
});

export type GitHubIssue = typeof githubIssues.$inferSelect;
export type InsertGitHubIssue = typeof githubIssues.$inferInsert;

/**
 * Notifications table - stores notification history
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["deadline_reminder", "task_alert", "payment_due", "critical_deadline", "system"]).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  relatedTaskId: int("relatedTaskId"),
  relatedDeadlineId: int("relatedDeadlineId"),
  isRead: boolean("isRead").default(false).notNull(),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Sync Log table - tracks when integrations were last synced
 */
export const syncLogs = mysqlTable("sync_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  integrationType: varchar("integrationType", { length: 50 }).notNull(),
  lastSyncAt: timestamp("lastSyncAt").notNull(),
  nextSyncAt: timestamp("nextSyncAt"),
  status: mysqlEnum("status", ["success", "failed", "pending"]).default("pending").notNull(),
  errorMessage: text("errorMessage"),
  itemsProcessed: int("itemsProcessed").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SyncLog = typeof syncLogs.$inferSelect;
export type InsertSyncLog = typeof syncLogs.$inferInsert;
